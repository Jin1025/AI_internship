#
# Magic canAI Input Transformers
#
# 1. Removes columns to ignore (keeping only selected columns).
# 2. Imputes missing values by mean value for numerical columns, and <NA>/mode for categorical ones.
# 3. Encodes to numbers for categorical columns.
#

import numpy as np
import pandas as pd
from sklearn.base import TransformerMixin
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import OrdinalEncoder
from sklearn.preprocessing import StandardScaler

# Transformers
class InputSelector(TransformerMixin):
    """
    Select columns of interest
    """

    def __init__(self, target, select):
        self.target = target
        self.select = select

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        cols = X.columns.tolist()
        for col in cols:                        # Drop uninterested columns
            if col not in self.select:
                X = X.drop(col, axis=1)
        if self.target in X:                    # Drop target
            X = X.drop(self.target, axis=1)
        return X

class ColumnSelector(TransformerMixin):
    """
    Split columns into numerical and categorical columns
    """

    def __init__(self, dtype):
        self.dtype = dtype
    
    def fit(self, X, y=None):
        if self.dtype == 'numerical':
            self.cols = X.select_dtypes(exclude='object').columns.tolist()
        elif self.dtype == 'categorical':
            self.cols = X.select_dtypes(include='object').columns.tolist()
        self.col_idx = [X.columns.get_loc(col) for col in self.cols]
        return self

    def transform(self, X, y=None):
        return X[self.cols]

class RationalImputer(TransformerMixin):
    """
    An imputer which replaces missing numerical values with mean value of the column,
    and "<NA>/mode" for categorical ones
    """

    def __init__(self, dtype):
        self.dtype = dtype
        self.imputed = []

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        X = X.copy()
        self.cols = X.columns

        if self.dtype == 'categorical':
            for col in X:
                if not X[col].isnull().any():
                    continue
                # X[col] = X[col].fillna('<NA>')    # mode() is meaningless sometimes
                try:
                    mode_value = X[col].mode().iloc[0]
                except:
                    mode_value = "<NA>"
                X[col] = X[col].fillna(mode_value)
                self.imputed += [col]
        else:
            for col in X:           # X.columns
                if not X[col].isnull().any():
                    continue
                mean_ = X[col].mean()
                if np.array_equal(X[col].dropna(), X[col].dropna().astype(int)):    # all is int
                    mean_ = int(mean_)
                    X[col] = X[col].fillna(mean_).astype(int)
                else:
                    X[col] = X[col].fillna(round(mean_, 4))
                self.imputed += [col]
            self.col_type = [str(X[col].dtype) for col in X]
        return X

class StandardSkaler(TransformerMixin):
    """
    Run StandardScaler with empty dataframe in mind
    """

    def __init__(self):
        self.scaler = StandardScaler()

    def fit(self, X, y=None):
        # if len(X.columns) > 0:
        #     self.scaler.fit(X)
        return self

    def transform(self, X, y=None):
        # if len(X.columns) > 0:
        #     return pd.DataFrame(self.scaler.transform(X), columns=X.columns)
        return X

    def inverse_transform(self, X, y=None):
        # if len(X.columns) > 0:
        #     return pd.DataFrame(self.scaler.inverse_transform(X), columns=X.columns)
        return X

def transformers(state):
    """
    Shorthands for pipeline makers
    """

    return Pipeline(steps=[
               ("input_selector", InputSelector(target=state.target,
                                                select=state.select)),
               ("preprocessing", FeatureUnion([
                   ("cat_pipe", Pipeline(steps=[
                       ("cat_selector", ColumnSelector(dtype='categorical')),
                       ("cat_imputer", RationalImputer(dtype='categorical')),
                       ("ord_encoder", 
                           OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1))])),
                   ("num_pipe", Pipeline(steps=[
                       ("num_selector", ColumnSelector(dtype='numerical')),
                       ("num_imputer", RationalImputer(dtype='numerical')),
                       ("std_scaler", StandardSkaler()),
                       ]))
                   ])
               )
           ])

def model_with_transformers(state):
    """
    Builds a pipeline composed up of input transformers and a trained model
    """

    return Pipeline(steps=[
               ("input_transformers", state.transformers),
               ("trained_model", state.model)
           ])

def union_component(pipe, lev1, lev2):
    # Hack to access named components of a FeatureUnion
    return dict(pipe.named_steps['preprocessing'].transformer_list).get(lev1).named_steps[lev2]

