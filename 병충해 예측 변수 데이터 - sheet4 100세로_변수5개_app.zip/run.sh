pip3 install -r requirements.txt >/dev/null 2>&1
/usr/bin/python3 app.py