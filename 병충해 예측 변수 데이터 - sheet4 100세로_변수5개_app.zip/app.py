# Import packages
import pandas as pd
import gradio as gr
import pickle

# Load the model file
with open('병충해 예측 변수 데이터 - sheet4 100세로_변수5개_model.pkl', 'rb') as f:   
    model = pickle.load(f)

# The predicion workhorse
def predict(*args):
    point = pd.DataFrame({
        'pH_level': [args[0]],
        'water_given_per_week': [args[1]],
        'temperature': [args[2]],
        'wind': [args[3]],
        'month': [args[4]]
    })
    return '<strong>disease_insect: ' + str(model.predict(point)[0]) + '</strong>'

# User Interface
number = gr.components.Number
radio = gr.components.Radio
dropdown = gr.components.Dropdown
text = gr.components.Textbox

with gr.Blocks() as service:
    gr.Markdown(value="<h4>병충해 예측 변수 데이터 - sheet4 100세로 변수5개 'disease_insect' Predictor</h4>Powered by <b>Magic canAI</b>")

    # User inputs
    pHlevel = number(value=5.835, label="pH_level")
    watergivenperweek = number(value=2, label="water_given_per_week")
    temperature = number(value=28, label="temperature")
    wind = number(value=0.6933, label="wind")
    month = number(value=7, label="month")

    # The output
    output = gr.Markdown(label="Prediction")

    # Command controls
    check_btn = gr.components.Button("Predict")
    check_btn.click(fn=predict, inputs=[pHlevel, watergivenperweek, temperature, wind, month], outputs=output)

    # Launch the app
    service.launch(debug=True)
###
