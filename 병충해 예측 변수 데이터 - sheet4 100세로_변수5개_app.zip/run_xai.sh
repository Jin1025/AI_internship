pip3 install -r requirements_xai.txt >/dev/null 2>&1
/usr/bin/python3 app_xai.py